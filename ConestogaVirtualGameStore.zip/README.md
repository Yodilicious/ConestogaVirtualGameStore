# Conestoga Virtual Game Store
Online games sales application!

# Instructions

* Make sure you have .NET Core 2.0 SDK Installed.

1. Pull repository from Github
2. In Visual Studio Open "Tool -> NuGet Package Manager -> Package Manager Console"
3. In the Package Manager Console write "Update-Database -Verbose"
4. Make sure the connection string is pointing to the correct server. Default is "localhost".