﻿namespace ConestogaVirtualGameStore.Web.Models
{
    public class BaseModel
    {
        public long RecordId { get; set; }
    }
}
