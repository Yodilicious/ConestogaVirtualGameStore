﻿namespace ConestogaVirtualGameStore.Web.Models.ViewModels
{
    public class FriendViewModel
    {
        public string Id { get; set; }
        public string Email { get; set; }
        public bool IsFriend { get; set; }
    }
}
