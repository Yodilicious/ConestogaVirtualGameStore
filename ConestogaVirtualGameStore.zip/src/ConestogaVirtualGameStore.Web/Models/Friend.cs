﻿namespace ConestogaVirtualGameStore.Web.Models
{
    public class Friend : BaseModel
    {
        public string UserId { get; set; }
        public string FriendId { get; set; }
    }
}
