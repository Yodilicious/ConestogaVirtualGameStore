using System.ComponentModel.DataAnnotations;

namespace ConestogaVirtualGameStore.Web.Models.AccountViewModels
{
    public class ExternalLoginViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
