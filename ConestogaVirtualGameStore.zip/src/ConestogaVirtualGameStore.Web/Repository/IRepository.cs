﻿namespace ConestogaVirtualGameStore.Web.Repository
{
    public interface IRepository
    {
        void Save();
    }
}
